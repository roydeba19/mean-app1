import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/user';
import { AppConstants } from "../config/app-constants";

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  _apiURL = AppConstants.apiURL;
  constructor(private http: HttpClient) { }

  public login(userInfo: User){
    return this.http.post(this._apiURL + 'login',userInfo); 
  }

  public home(){
    return this.http.get(this._apiURL + 'home'); 
  }
  
}
