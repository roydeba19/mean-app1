import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from  '@angular/forms';
import {MatDialogRef} from '@angular/material/dialog';
import { ApiService } from  '../../services/api.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  isSubmitted  =  false;
  serverMessage = {
    status:false,
    message:''
  };
  responseData:any;
  isLoader = false;
  userObj:any;

  constructor(private apiService: ApiService,private formBuilder: FormBuilder,private dialogRef:MatDialogRef<LoginComponent>) { }

  ngOnInit(): void {
    this.loginForm  =  this.formBuilder.group({
      email: ['', [Validators.required,Validators.email]],
      password: ['', Validators.required]
      });
  }

  get formControls() { return this.loginForm.controls; }

  login(){
    console.log(this.loginForm.value);
    this.isSubmitted = true;    
    if(this.loginForm.invalid){
      return false;
    }
    this.apiService.login(this.loginForm.value).subscribe(data => {
      this.isLoader = true;
      this.responseData = data;
      if (this.responseData.status == 1) {
        this.isLoader = false;
        console.log(this.responseData);
        // localStorage.setItem('USER_DATA',JSON.stringify(this.responseData.passenger));
        this.serverMessage.status = false;
        this.serverMessage.message = '';
        this.dialogRef.close();        
      } else {
        this.serverMessage.status = true;
        this.serverMessage.message = this.responseData.message;
      }
    },
    error  => {    
      console.log("Error", error);    
      // this.dialog.open(AlertMessageComponent,{
      //   data: { message: 'Invalid login details' },
      // });
      return false;
    });
    
  }

}
