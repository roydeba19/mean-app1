export class AppConstants {
    //public static apiURL: string = "https://dream-shop.herokuapp.com/api/";
    public static apiURL: string = "http://localhost:5000/api/";
}
