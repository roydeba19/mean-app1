const express = require('express')
const bodyParser = require('body-parser')
const path = require('path')
const http = require('http')
const dotenv = require('dotenv')
const app = express()
const server = http.createServer(app)
//load env variables
dotenv.config({path:'./core/config/config.env'})

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))
// parse application/json
app.use(bodyParser.json())

app.use(express.static('ui'))

app.use('/', express.static(path.join(__dirname, 'ui')))
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
  })
app.use('/api',require('./routes/api'))

app.get('/admin',(req,res) => {
    res.send('Hello Admin !!!')
})

const PORT = process.env.PORT || 3000

server.listen(PORT,()=>{
    console.log(`Server is running in ${process.env.NODE_ENV} mode on port ${PORT}`)
})