const express = require('express')
const {users,login,home} = require('../controllers/api')
const router = express.Router()

router.route('/users').get(users)
router.route('/home').get(home)
router.route('/login').post(login)
module.exports = router