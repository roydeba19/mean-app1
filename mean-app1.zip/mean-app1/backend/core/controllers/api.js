exports.users = async (req,res) => {
    let users = [
                    {
                        name:'Rony Jones',
                        email:'rony123@yopmail.com'
                    },
                    {
                        name:'Sam Bill',
                        email:'sam123@yopmail.com'
                    }
                ]
    res.json(users)            
}

exports.home = async (req,res) => {    
    let productCount = 9
    let products = []
    for (let i = 0;i < productCount;i++) {
        let productObj = {}
        productObj.title = 'Product ' + (i + 1)
        productObj.description = 'Description ' + (i + 1)
        products.push(productObj)
    }
    res.status(200).json(products)            
}

exports.login = async (req,res) => {
    let responseObj = {}
    try {
        const _checkEmail = 'rony123@yopmail.com'
        const _checkPassword = '123456'     
        if (req.body.email == _checkEmail && req.body.password == _checkPassword) {
            responseObj.status = 1
            responseObj.message = "Login successful"            
        } else {
            responseObj.status = 0
            responseObj.message = "Login failed"
        }
        res.status(200).send(responseObj)
    } catch (e) {
        responseObj.status = 0
        responseObj.message = e.message
        res.status(400).send(responseObj)
    }
}